'use client';

import { useEffect, useState } from 'react';
import { ArrowLeft, Store } from 'lucide-react';
import { getStores, getOrdersByStore } from '@/lib/data-store';
import type { Store as StoreType } from '@/lib/dispatch-types';
import Card from './Card';

interface StoreScreenProps {
  onNavigate: (screen: string) => void;
}

export default function StoreScreen({ onNavigate }: StoreScreenProps) {
  const [stores, setStores] = useState<StoreType[]>([]);

  useEffect(() => {
    try {
      setStores(getStores());
    } catch (error) {
      console.error('Load stores error:', error);
    }
  }, []);

  return (
    <div style={{
      padding: '20px 16px',
      minHeight: 'calc(100vh - 120px)'
    }}>
      <div style={{
        maxWidth: '600px',
        margin: '0 auto'
      }}>
        <button
          onClick={() => onNavigate('main')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '10px 16px',
            background: '#6fa8dc',
            color: '#ffffff',
            border: 'none',
            borderRadius: '14px',
            fontSize: '15px',
            fontWeight: '600',
            cursor: 'pointer',
            marginBottom: '20px'
          }}
        >
          <ArrowLeft size={18} />
          戻る
        </button>

        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          marginBottom: '20px'
        }}>
          <div style={{
            width: '40px',
            height: '40px',
            borderRadius: '12px',
            background: '#fef3c7',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <Store size={22} color="#d97706" />
          </div>
          <div style={{
            fontSize: '20px',
            fontWeight: '700',
            color: '#111827'
          }}>
            店舗
          </div>
        </div>

        <div style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '12px'
        }}>
          {stores.map(store => {
            const orders = getOrdersByStore(store.id);
            return (
              <Card key={store.id}>
                <div style={{
                  fontSize: '16px',
                  fontWeight: '700',
                  color: '#111827',
                  marginBottom: '8px'
                }}>
                  {store.name}
                </div>
                <div style={{
                  fontSize: '13px',
                  color: '#6b7280',
                  marginBottom: '4px'
                }}>
                  {store.address}
                </div>
                <div style={{
                  fontSize: '13px',
                  color: '#6b7280',
                  marginBottom: '8px'
                }}>
                  {store.phone}
                </div>
                <div style={{
                  fontSize: '13px',
                  color: '#2563eb',
                  fontWeight: '600'
                }}>
                  配送待ち: {orders.filter(o => o.status !== 'completed').length}件
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
