'use client';

interface CardProps {
  children: React.ReactNode;
}

export default function Card({ children }: CardProps) {
  return (
    <div style={{
      background: '#ffffff',
      borderRadius: '14px',
      padding: '16px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.06)'
    }}>
      {children}
    </div>
  );
}
