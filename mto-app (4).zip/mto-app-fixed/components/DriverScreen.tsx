'use client';

import { useEffect, useState } from 'react';
import { ArrowLeft, UserCircle } from 'lucide-react';
import { getDrivers, getOrdersByDriver } from '@/lib/data-store';
import type { Driver } from '@/lib/dispatch-types';
import Card from './Card';
import Badge from './Badge';

interface DriverScreenProps {
  onNavigate: (screen: string) => void;
}

export default function DriverScreen({ onNavigate }: DriverScreenProps) {
  const [drivers, setDrivers] = useState<Driver[]>([]);

  useEffect(() => {
    try {
      setDrivers(getDrivers());
    } catch (error) {
      console.error('Load drivers error:', error);
    }
  }, []);

  return (
    <div style={{
      padding: '20px 16px',
      minHeight: 'calc(100vh - 120px)'
    }}>
      <div style={{
        maxWidth: '600px',
        margin: '0 auto'
      }}>
        <button
          onClick={() => onNavigate('main')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '10px 16px',
            background: '#6fa8dc',
            color: '#ffffff',
            border: 'none',
            borderRadius: '14px',
            fontSize: '15px',
            fontWeight: '600',
            cursor: 'pointer',
            marginBottom: '20px'
          }}
        >
          <ArrowLeft size={18} />
          戻る
        </button>

        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          marginBottom: '20px'
        }}>
          <div style={{
            width: '40px',
            height: '40px',
            borderRadius: '12px',
            background: '#dbeafe',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <UserCircle size={22} color="#2563eb" />
          </div>
          <div style={{
            fontSize: '20px',
            fontWeight: '700',
            color: '#111827'
          }}>
            ドライバー
          </div>
        </div>

        <div style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '12px'
        }}>
          {drivers.map(driver => {
            const orders = getOrdersByDriver(driver.id);
            return (
              <Card key={driver.id}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  marginBottom: '8px'
                }}>
                  <span style={{
                    fontSize: '16px',
                    fontWeight: '700',
                    color: '#111827'
                  }}>
                    {driver.name}
                  </span>
                  <Badge variant={driver.status}>
                    {driver.status === 'available' ? '待機中' :
                     driver.status === 'busy' ? '配送中' : 'オフライン'}
                  </Badge>
                </div>
                <div style={{
                  fontSize: '13px',
                  color: '#6b7280',
                  marginBottom: '8px'
                }}>
                  現在地: {driver.currentLocation}
                </div>
                <div style={{
                  fontSize: '13px',
                  color: '#2563eb',
                  fontWeight: '600'
                }}>
                  担当中: {orders.filter(o => o.status === 'assigned').length}件
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
