'use client';

import { useEffect, useState } from 'react';
import { ArrowLeft, Settings } from 'lucide-react';
import { getStats } from '@/lib/data-store';
import type { Stats } from '@/lib/dispatch-types';

interface AdminScreenProps {
  onNavigate: (screen: string) => void;
}

export default function AdminScreen({ onNavigate }: AdminScreenProps) {
  const [stats, setStats] = useState<Stats | null>(null);
  const [currentTime, setCurrentTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const year = now.getFullYear();
      const month = String(now.getMonth() + 1).padStart(2, '0');
      const day = String(now.getDate()).padStart(2, '0');
      const weekdays = ['日', '月', '火', '水', '木', '金', '土'];
      const weekday = weekdays[now.getDay()];
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      setCurrentTime(`${year}/${month}/${day}（${weekday}） ${hours}:${minutes}`);
    };

    updateTime();
    const timer = setInterval(updateTime, 60000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    try {
      const data = getStats();
      setStats(data);
    } catch (error) {
      console.error('Stats load error:', error);
      setStats({
        totalOrders: 0,
        completedOrders: 0,
        activeDrivers: 0,
        totalStores: 0
      });
    }
  }, []);

  if (!stats) {
    return (
      <div style={{
        padding: '20px 16px',
        minHeight: 'calc(100vh - 120px)'
      }}>
        <div style={{
          maxWidth: '600px',
          margin: '0 auto'
        }}>
          <button
            onClick={() => onNavigate('main')}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '10px 16px',
              background: '#6fa8dc',
              color: '#ffffff',
              border: 'none',
              borderRadius: '14px',
              fontSize: '15px',
              fontWeight: '600',
              cursor: 'pointer',
              marginBottom: '20px'
            }}
          >
            <ArrowLeft size={18} />
            戻る
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{
      padding: '20px 16px',
      minHeight: 'calc(100vh - 120px)'
    }}>
      <div style={{
        maxWidth: '600px',
        margin: '0 auto'
      }}>
        <button
          onClick={() => onNavigate('main')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '10px 16px',
            background: '#6fa8dc',
            color: '#ffffff',
            border: 'none',
            borderRadius: '14px',
            fontSize: '15px',
            fontWeight: '600',
            cursor: 'pointer',
            marginBottom: '20px'
          }}
        >
          <ArrowLeft size={18} />
          戻る
        </button>

        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          marginBottom: '20px'
        }}>
          <div style={{
            width: '40px',
            height: '40px',
            borderRadius: '12px',
            background: '#e0e7ff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <Settings size={22} color="#6366f1" />
          </div>
          <div>
            <div style={{
              fontSize: '20px',
              fontWeight: '700',
              color: '#111827',
              marginBottom: '2px'
            }}>
              管理
            </div>
            {currentTime && (
              <div style={{
                fontSize: '13px',
                color: '#6b7280'
              }}>
                {currentTime}
              </div>
            )}
          </div>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(2, 1fr)',
          gap: '12px',
          marginBottom: '24px'
        }}>
          <div style={{
            background: '#ffffff',
            borderRadius: '14px',
            padding: '16px',
            boxShadow: '0 1px 3px rgba(0,0,0,0.06)'
          }}>
            <div style={{
              fontSize: '13px',
              color: '#6b7280',
              marginBottom: '6px'
            }}>
              総注文数
            </div>
            <div style={{
              fontSize: '28px',
              fontWeight: '700',
              color: '#111827'
            }}>
              {stats.totalOrders}
            </div>
          </div>

          <div style={{
            background: '#ffffff',
            borderRadius: '14px',
            padding: '16px',
            boxShadow: '0 1px 3px rgba(0,0,0,0.06)'
          }}>
            <div style={{
              fontSize: '13px',
              color: '#6b7280',
              marginBottom: '6px'
            }}>
              完了済み
            </div>
            <div style={{
              fontSize: '28px',
              fontWeight: '700',
              color: '#63b37b'
            }}>
              {stats.completedOrders}
            </div>
          </div>

          <div style={{
            background: '#ffffff',
            borderRadius: '14px',
            padding: '16px',
            boxShadow: '0 1px 3px rgba(0,0,0,0.06)'
          }}>
            <div style={{
              fontSize: '13px',
              color: '#6b7280',
              marginBottom: '6px'
            }}>
              稼働中ドライバー
            </div>
            <div style={{
              fontSize: '28px',
              fontWeight: '700',
              color: '#2563eb'
            }}>
              {stats.activeDrivers}
            </div>
          </div>

          <div style={{
            background: '#ffffff',
            borderRadius: '14px',
            padding: '16px',
            boxShadow: '0 1px 3px rgba(0,0,0,0.06)'
          }}>
            <div style={{
              fontSize: '13px',
              color: '#6b7280',
              marginBottom: '6px'
            }}>
              登録店舗数
            </div>
            <div style={{
              fontSize: '28px',
              fontWeight: '700',
              color: '#d97706'
            }}>
              {stats.totalStores}
            </div>
          </div>
        </div>

        <div style={{
          background: '#ffffff',
          borderRadius: '14px',
          padding: '20px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.06)'
        }}>
          <div style={{
            fontSize: '16px',
            fontWeight: '700',
            color: '#111827',
            marginBottom: '16px'
          }}>
            システム情報
          </div>
          
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '12px'
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              paddingBottom: '12px',
              borderBottom: '1px solid #e5e7eb'
            }}>
              <span style={{
                fontSize: '14px',
                color: '#6b7280'
              }}>
                データストレージ
              </span>
              <span style={{
                fontSize: '14px',
                fontWeight: '600',
                color: '#111827'
              }}>
                localStorage
              </span>
            </div>

            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              paddingBottom: '12px',
              borderBottom: '1px solid #e5e7eb'
            }}>
              <span style={{
                fontSize: '14px',
                color: '#6b7280'
              }}>
                業務時間
              </span>
              <span style={{
                fontSize: '14px',
                fontWeight: '600',
                color: '#111827'
              }}>
                20:00 〜 翌03:00
              </span>
            </div>

            <div style={{
              display: 'flex',
              justifyContent: 'space-between'
            }}>
              <span style={{
                fontSize: '14px',
                color: '#6b7280'
              }}>
                バージョン
              </span>
              <span style={{
                fontSize: '14px',
                fontWeight: '600',
                color: '#111827'
              }}>
                1.0.0
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
