'use client';

import { ChevronRight, LucideIcon } from 'lucide-react';

interface NavCardProps {
  icon: LucideIcon;
  title: string;
  subtitle: string;
  onClick: () => void;
  iconBgColor: string;
  iconColor: string;
}

export default function NavCard({
  icon: Icon,
  title,
  subtitle,
  onClick,
  iconBgColor,
  iconColor
}: NavCardProps) {
  return (
    <button
      onClick={onClick}
      style={{
        width: '100%',
        background: '#ffffff',
        border: 'none',
        borderRadius: '14px',
        padding: '16px',
        display: 'flex',
        alignItems: 'center',
        gap: '14px',
        cursor: 'pointer',
        boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
        textAlign: 'left'
      }}
    >
      <div
        style={{
          width: '48px',
          height: '48px',
          borderRadius: '12px',
          background: iconBgColor,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0
        }}
      >
        <Icon size={24} color={iconColor} />
      </div>
      <div style={{ flex: 1 }}>
        <div style={{
          fontSize: '16px',
          fontWeight: '700',
          color: '#111827',
          marginBottom: '4px'
        }}>
          {title}
        </div>
        <div style={{
          fontSize: '13px',
          color: '#6b7280'
        }}>
          {subtitle}
        </div>
      </div>
      <ChevronRight size={20} color="#d1d5db" />
    </button>
  );
}
