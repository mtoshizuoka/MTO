'use client';

import { useEffect, useState } from 'react';
import { ArrowLeft, Truck } from 'lucide-react';
import { getOrders, getDrivers, assignOrderToDriver, completeOrder } from '@/lib/data-store';
import type { Order, Driver } from '@/lib/dispatch-types';
import Card from './Card';
import Badge from './Badge';

interface DispatchScreenProps {
  onNavigate: (screen: string) => void;
}

export default function DispatchScreen({ onNavigate }: DispatchScreenProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);

  const loadData = () => {
    try {
      setOrders(getOrders());
      setDrivers(getDrivers());
    } catch (error) {
      console.error('Load data error:', error);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleAssign = (orderId: string, driverId: string) => {
    assignOrderToDriver(orderId, driverId);
    loadData();
  };

  const handleComplete = (orderId: string) => {
    completeOrder(orderId);
    loadData();
  };

  return (
    <div style={{
      padding: '20px 16px',
      minHeight: 'calc(100vh - 120px)'
    }}>
      <div style={{
        maxWidth: '600px',
        margin: '0 auto'
      }}>
        <button
          onClick={() => onNavigate('main')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '10px 16px',
            background: '#6fa8dc',
            color: '#ffffff',
            border: 'none',
            borderRadius: '14px',
            fontSize: '15px',
            fontWeight: '600',
            cursor: 'pointer',
            marginBottom: '20px'
          }}
        >
          <ArrowLeft size={18} />
          戻る
        </button>

        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          marginBottom: '20px'
        }}>
          <div style={{
            width: '40px',
            height: '40px',
            borderRadius: '12px',
            background: '#d1fae5',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <Truck size={22} color="#059669" />
          </div>
          <div style={{
            fontSize: '20px',
            fontWeight: '700',
            color: '#111827'
          }}>
            配車管理
          </div>
        </div>

        <div style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '12px'
        }}>
          {orders.map((order, index) => (
            <Card key={order.id}>
              <div style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: '12px'
              }}>
                <div style={{
                  width: '28px',
                  height: '28px',
                  borderRadius: '50%',
                  background: '#6fa8dc',
                  color: '#ffffff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '13px',
                  fontWeight: '700',
                  flexShrink: 0
                }}>
                  {index + 1}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    marginBottom: '8px'
                  }}>
                    <span style={{
                      fontSize: '16px',
                      fontWeight: '700',
                      color: '#111827'
                    }}>
                      {order.storeName}
                    </span>
                    <Badge variant={order.status}>
                      {order.status === 'pending' ? '未割当' : 
                       order.status === 'assigned' ? '配車済' : '完了'}
                    </Badge>
                  </div>
                  <div style={{
                    fontSize: '13px',
                    color: '#6b7280',
                    marginBottom: '4px'
                  }}>
                    集荷: {order.pickupTime}
                  </div>
                  <div style={{
                    fontSize: '13px',
                    color: '#6b7280',
                    marginBottom: '8px'
                  }}>
                    配送先: {order.deliveryAddress}
                  </div>
                  {order.driverName && (
                    <div style={{
                      fontSize: '13px',
                      color: '#2563eb',
                      fontWeight: '600',
                      marginBottom: '8px'
                    }}>
                      担当: {order.driverName}
                    </div>
                  )}
                  {order.status === 'pending' && (
                    <div style={{
                      display: 'flex',
                      gap: '6px',
                      flexWrap: 'wrap'
                    }}>
                      {drivers.filter(d => d.status === 'available').map(driver => (
                        <button
                          key={driver.id}
                          onClick={() => handleAssign(order.id, driver.id)}
                          style={{
                            padding: '6px 12px',
                            background: '#dbeafe',
                            color: '#2563eb',
                            border: 'none',
                            borderRadius: '8px',
                            fontSize: '12px',
                            fontWeight: '600',
                            cursor: 'pointer'
                          }}
                        >
                          {driver.name}
                        </button>
                      ))}
                    </div>
                  )}
                  {order.status === 'assigned' && (
                    <button
                      onClick={() => handleComplete(order.id)}
                      style={{
                        padding: '8px 16px',
                        background: '#63b37b',
                        color: '#ffffff',
                        border: 'none',
                        borderRadius: '10px',
                        fontSize: '13px',
                        fontWeight: '600',
                        cursor: 'pointer'
                      }}
                    >
                      完了
                    </button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
